/* Continuum da placa aterosclerótica — animação da artéria coronária.
   Cada etapa define alvos numéricos; o desenho interpola suavemente até eles. */
(function () {
  'use strict';

  // p: tamanho da placa (0–1) · ldl: partículas de colesterol · rup: ruptura da capa
  // thr: trombo (0–1) · flow: velocidade do sangue
  var STAGES = [
    { short: 'Artéria saudável', title: 'Artéria saudável',
      text: 'A parede interna é lisa e o sangue passa livremente, levando oxigênio ao músculo do coração.',
      feel: 'Nada. O coração recebe todo o sangue de que precisa.',
      cross: 'Passagem livre', p: 0, ldl: 0, rup: 0, thr: 0, flow: 1 },
    { short: 'Gordura entra na parede', title: 'O começo: a gordura entra na parede',
      text: 'Colesterol alto, pressão alta, diabetes e cigarro machucam o revestimento interno da artéria. Partículas de colesterol (LDL) começam a se infiltrar na parede.',
      feel: 'Nada. Só os exames de sangue mostram o colesterol alto.',
      cross: 'Passagem livre', p: 0.04, ldl: 1, rup: 0, thr: 0, flow: 1 },
    { short: 'Estria gordurosa', title: 'Estria gordurosa',
      text: 'As células de defesa tentam “limpar” o colesterol, ficam cheias de gordura e se acumulam ali. É o início da placa — pode começar ainda na juventude.',
      feel: 'Nada. É uma fase silenciosa que dura muitos anos.',
      cross: 'Início do acúmulo', p: 0.2, ldl: 1, rup: 0, thr: 0, flow: 1 },
    { short: 'Placa formada', title: 'Placa de ateroma',
      text: 'Com o tempo forma-se um núcleo de gordura coberto por uma capa de tecido. A artéria ainda consegue levar sangue suficiente.',
      feel: 'Geralmente nada. A placa pode aparecer em exames, como o escore de cálcio.',
      cross: 'Passagem reduzida', p: 0.45, ldl: 0, rup: 0, thr: 0, flow: 0.95 },
    { short: 'Artéria estreitada', title: 'A placa estreita a passagem',
      text: 'Quando a placa ocupa boa parte da artéria, o sangue que passa não é suficiente nos momentos em que o coração trabalha mais.',
      feel: 'Angina: aperto ou dor no peito ao esforço, que melhora com o repouso.',
      cross: 'Passagem muito reduzida', p: 0.78, ldl: 0, rup: 0, thr: 0, flow: 0.6 },
    { short: 'Ruptura da placa', title: 'A capa da placa se rompe',
      text: 'A capa que cobre a placa pode se romper de repente — inclusive em placas que ainda não eram grandes. A gordura de dentro entra em contato com o sangue.',
      feel: 'Pode não haver aviso. Por isso tratamos mesmo quem não sente nada.',
      cross: 'Placa instável', p: 0.78, ldl: 0, rup: 1, thr: 0.12, flow: 0.6, danger: true },
    { short: 'Coágulo e infarto', title: 'Coágulo e infarto',
      text: 'O corpo reage como se fosse um ferimento e forma um coágulo em minutos. Se ele fecha a artéria, o músculo adiante fica sem oxigênio e começa a morrer.',
      feel: 'Dor forte no peito que não passa, suor frio, falta de ar. É emergência: cada minuto conta.',
      cross: 'Artéria fechada', p: 0.78, ldl: 0, rup: 1, thr: 1, flow: 0.8, danger: true }
  ];

  var NS = 'http://www.w3.org/2000/svg';
  var $ = function (id) { return document.getElementById(id); };
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var TOP = 100, BOT = 260, CX = 450, SPREAD = 125;
  var cur = { p: 0, ldl: 0, rup: 0, thr: 0, flow: 1 };
  var idx = 0, timer = null;

  function bump(x) { var d = (x - CX) / SPREAD; return Math.exp(-d * d); }
  function botAt(x, p) { return BOT - p * 150 * bump(x); }
  function topAt(x, p) { return TOP + p * 22 * bump(x); }

  // --- hemácias ---
  var cells = [];
  (function () {
    var g = $('cells');
    for (var i = 0; i < 38; i++) {
      var e = document.createElementNS(NS, 'ellipse');
      e.setAttribute('rx', 9); e.setAttribute('ry', 6); e.setAttribute('fill', '#c0392b');
      g.appendChild(e);
      cells.push({ el: e, x: Math.random() * 900, f: 0.1 + Math.random() * 0.8,
                   v: 1.2 + Math.random() * 1.2, stop: 60 + Math.random() * 300, rot: Math.random() * 50 - 25 });
    }
  })();

  // --- partículas de LDL ---
  (function () {
    var g = $('ldl');
    var pts = [[380,248],[410,236],[440,252],[470,240],[500,250],[530,238],[455,222],[490,226],
               [400,268],[435,272],[470,266],[505,274],[540,268],[420,280],[485,282]];
    pts.forEach(function (pt) {
      var c = document.createElementNS(NS, 'circle');
      c.setAttribute('cx', pt[0]); c.setAttribute('cy', pt[1]); c.setAttribute('r', 5);
      g.appendChild(c);
    });
  })();

  function edge(fn, p, x0, x1) {
    var d = '';
    for (var x = x0; x <= x1; x += 10) d += (d ? 'L' : 'M') + x + ' ' + fn(x, p).toFixed(1);
    return d;
  }

  function draw() {
    var p = cur.p, t = cur.thr;
    // placa (núcleo + capa)
    $('plaque').setAttribute('d', edge(botAt, p, 150, 750) + 'L750 ' + BOT + 'L150 ' + BOT + 'Z');
    $('plaqueTop').setAttribute('d', edge(topAt, p, 150, 750) + 'L750 ' + TOP + 'L150 ' + TOP + 'Z');
    var showCap = p > 0.1 ? 1 : 0;
    $('cap').setAttribute('d', edge(botAt, p, 250, 650)); $('cap').setAttribute('opacity', showCap);
    $('capTop').setAttribute('d', edge(topAt, p, 300, 600)); $('capTop').setAttribute('opacity', p > 0.3 ? 1 : 0);

    // ruptura: fenda no topo da placa
    var apex = botAt(CX, p);
    $('crack').setAttribute('d', 'M' + (CX - 26) + ' ' + (botAt(CX - 26, p) - 4) + 'L' + (CX + 26) + ' ' + (botAt(CX + 26, p) - 4) +
      'L' + (CX + 8) + ' ' + (apex + 34) + 'L' + (CX - 10) + ' ' + (apex + 30) + 'Z');
    $('crack').setAttribute('opacity', cur.rup > 0.5 ? 1 : 0);

    // trombo: cresce da fenda até encostar na parede oposta
    if (t > 0.01) {
      var w = 22 + t * 50, ceil = topAt(CX, p), d = '';
      var top = apex - t * (apex - ceil) - (t > 0.9 ? 4 : 0);
      for (var a = 0; a <= 12; a++) {
        var x = CX - w + (2 * w * a) / 12, k = Math.sin((Math.PI * a) / 12);
        d += (a ? 'L' : 'M') + x.toFixed(1) + ' ' + (botAt(x, p) - k * (botAt(x, p) - top) * (0.75 + 0.25 * k)).toFixed(1);
      }
      for (var b = 12; b >= 0; b--) { var xb = CX - w + (2 * w * b) / 12; d += 'L' + xb.toFixed(1) + ' ' + (botAt(xb, p) + 6).toFixed(1); }
      $('thrombus').setAttribute('d', d + 'Z');
    } else { $('thrombus').setAttribute('d', ''); }

    // corte transversal
    var rl = 86 * (1 - 0.74 * p);
    $('xLumen').setAttribute('r', rl.toFixed(1)); $('xLumen').setAttribute('cy', (160 - (86 - rl) * 0.8).toFixed(1));
    $('xThr').setAttribute('r', rl.toFixed(1)); $('xThr').setAttribute('cy', (160 - (86 - rl) * 0.8).toFixed(1));
    $('xThr').setAttribute('opacity', Math.max(0, (t - 0.1) / 0.9).toFixed(2));
    $('ischemia').setAttribute('opacity', (Math.max(0, t - 0.3) * 0.9).toFixed(2));
  }

  function moveCells() {
    var blocked = cur.thr > 0.6, wall = CX - 75;
    cells.forEach(function (c) {
      var v = c.v * cur.flow;
      if (blocked && c.x < wall) {
        var lim = wall - c.stop * 0.9;
        c.x = c.x < lim ? Math.min(c.x + v, lim) : c.x;
      } else {
        c.x += v;
        if (c.x > 915) { c.x = -15; c.f = 0.1 + Math.random() * 0.8; }
      }
      var y0 = topAt(c.x, cur.p), y1 = botAt(c.x, cur.p);
      var y = y0 + 8 + c.f * Math.max(4, y1 - y0 - 16);
      c.el.setAttribute('transform', 'translate(' + c.x.toFixed(1) + ' ' + y.toFixed(1) + ') rotate(' + c.rot + ')');
      c.el.setAttribute('opacity', blocked && c.x > wall ? 0.25 : 1);
    });
  }

  function frame() {
    var s = STAGES[idx], k = reduced ? 1 : 0.07;
    ['p', 'ldl', 'rup', 'thr', 'flow'].forEach(function (key) { cur[key] += (s[key] - cur[key]) * k; });
    draw();
    if (!reduced) moveCells();
    requestAnimationFrame(frame);
  }

  function setOpacity(id, on) { $(id).setAttribute('opacity', on ? 1 : 0); }

  function go(i) {
    idx = Math.max(0, Math.min(STAGES.length - 1, i));
    var s = STAGES[idx];
    $('pNum').textContent = 'ETAPA ' + (idx + 1) + ' DE ' + STAGES.length;
    $('pTitle').textContent = s.title;
    $('pText').textContent = s.text;
    $('pFeel').textContent = s.feel;
    $('panel').classList.toggle('danger', !!s.danger);
    $('crossCap').textContent = s.cross;
    $('heartCap').textContent = s.thr === 1 ? 'Área do coração sem sangue' : (s.p > 0 ? 'Local da placa na coronária' : 'Coronárias sobre o coração');
    setOpacity('ldl', s.ldl);
    setOpacity('lblLdl', s.ldl && idx === 1);
    setOpacity('lblPlaque', s.p >= 0.2 && !s.rup);
    setOpacity('lblCap', s.rup && s.thr < 1);
    setOpacity('lblThr', s.thr === 1);
    setOpacity('lesion', s.p > 0);
    setOpacity('infarct', s.thr === 1);
    var y = botAt(CX + 14, s.p) - 2;
    $('lblCapLine').setAttribute('y2', y.toFixed(0)); $('lblCapLine').setAttribute('x2', CX + 16);
    Array.prototype.forEach.call($('steps').children, function (b, n) { b.setAttribute('aria-current', n === idx ? 'true' : 'false'); });
    $('prev').disabled = idx === 0;
    $('next').disabled = idx === STAGES.length - 1;
  }

  function stop() { if (timer) { clearInterval(timer); timer = null; $('play').textContent = '▶ Reproduzir'; } }
  function play() {
    if (timer) { stop(); return; }
    if (idx === STAGES.length - 1) go(0);
    $('play').textContent = '❚❚ Pausar';
    timer = setInterval(function () { if (idx >= STAGES.length - 1) stop(); else go(idx + 1); }, 6000);
  }

  STAGES.forEach(function (s, n) {
    var b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = '<b>' + (n + 1) + '</b>' + s.short;
    b.addEventListener('click', function () { stop(); go(n); });
    $('steps').appendChild(b);
  });
  $('prev').addEventListener('click', function () { stop(); go(idx - 1); });
  $('next').addEventListener('click', function () { stop(); go(idx + 1); });
  $('play').addEventListener('click', play);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight') { stop(); go(idx + 1); }
    else if (e.key === 'ArrowLeft') { stop(); go(idx - 1); }
  });

  go(0);
  requestAnimationFrame(frame);
})();
